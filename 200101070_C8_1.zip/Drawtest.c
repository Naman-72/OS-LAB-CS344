#include "types.h"
#include "stat.h"
#include "user.h"

int main(void)
{
	// buffer 1000 bytes
	static char buf[1000];

	// draw(func) in sysproc.c file which returns size if it size is less than  buffer
	int p = draw(buf,1000);

	if(p == -1){
		// if size is less due to unavailability of buffer then print -1
		printf(-1, "ERROR: Size is smaller than Buffer size .\n");
	}
	else {
		// is size is enough to hold print the  buffer size
		printf(1,"Size = %d bytes\n",p);
		printf(1,"%s\n",buf);
	}
	return 0;
}
